/**
 * Merge-o-matic 2000 - Main Application
 */

// Application State
const AppState = {
    files: {},          // fileName -> { file, data, columns, headerRow, ... }
    templateUrl: 'assets/Analysis Template.xlsx'
};

// DOM Elements
const elements = {
    fileInput: null,
    uploadZone: null,
    uploadStatus: null,
    fileList: null,
    fileConfigs: null,
    columnsSection: null,
    graphSection: null,
    timeSection: null,
    downloadSection: null,
    enableGraphing: null,
    graphColumnSelect: null,
    graphColumns: null,
    generateGraphBtn: null,
    graphContainer: null,
    startDate: null,
    startTime: null,
    endDate: null,
    endTime: null,
    durationDays: null,
    interval: null,
    alignmentOptions: null,
    createFileBtn: null,
    progressContainer: null,
    progressFill: null,
    progressText: null,
    downloadContainer: null,
    downloadBtn: null
};

/**
 * Initialize the application
 */
function init() {
    // Get DOM elements
    elements.fileInput = document.getElementById('file-input');
    elements.uploadZone = document.getElementById('upload-zone');
    elements.uploadStatus = document.getElementById('upload-status');
    elements.fileList = document.getElementById('file-list');
    elements.fileConfigs = document.getElementById('file-configs');
    elements.columnsSection = document.getElementById('columns-section');
    elements.graphSection = document.getElementById('graph-section');
    elements.timeSection = document.getElementById('time-section');
    elements.downloadSection = document.getElementById('download-section');
    elements.enableGraphing = document.getElementById('enable-graphing');
    elements.graphColumnSelect = document.getElementById('graph-column-select');
    elements.graphColumns = document.getElementById('graph-columns');
    elements.generateGraphBtn = document.getElementById('generate-graph-btn');
    elements.graphContainer = document.getElementById('graph-container');
    elements.startDate = document.getElementById('start-date');
    elements.startTime = document.getElementById('start-time');
    elements.endDate = document.getElementById('end-date');
    elements.endTime = document.getElementById('end-time');
    elements.durationDays = document.getElementById('duration-days');
    elements.interval = document.getElementById('interval');
    elements.alignmentOptions = document.getElementById('alignment-options');
    elements.createFileBtn = document.getElementById('create-file-btn');
    elements.progressContainer = document.getElementById('progress-container');
    elements.progressFill = document.getElementById('progress-fill');
    elements.progressText = document.getElementById('progress-text');
    elements.downloadContainer = document.getElementById('download-container');
    elements.downloadBtn = document.getElementById('download-btn');

    // Set up event listeners
    setupEventListeners();
    
    // Set default dates
    setDefaultDates();
}

/**
 * Set up all event listeners
 */
function setupEventListeners() {
    // File upload
    elements.fileInput.addEventListener('change', handleFileSelect);
    elements.uploadZone.addEventListener('click', () => elements.fileInput.click());
    elements.uploadZone.addEventListener('dragover', handleDragOver);
    elements.uploadZone.addEventListener('dragleave', handleDragLeave);
    elements.uploadZone.addEventListener('drop', handleDrop);

    // Range mode toggle
    document.querySelectorAll('input[name="range-mode"]').forEach(radio => {
        radio.addEventListener('change', handleRangeModeChange);
    });

    // Graphing checkbox
    elements.enableGraphing.addEventListener('change', handleGraphingToggle);
    elements.generateGraphBtn.addEventListener('click', generateGraph);

    // Create file button
    elements.createFileBtn.addEventListener('click', createCombinedFile);
}

/**
 * Set default start/end dates
 */
function setDefaultDates() {
    const today = new Date();
    const twoWeeksLater = new Date(today);
    twoWeeksLater.setDate(twoWeeksLater.getDate() + 14);

    elements.startDate.value = formatDateForInput(today);
    elements.endDate.value = formatDateForInput(twoWeeksLater);
}

/**
 * Format date for input[type="date"]
 */
function formatDateForInput(date) {
    return date.toISOString().split('T')[0];
}

// ===== FILE UPLOAD HANDLERS =====

function handleDragOver(e) {
    e.preventDefault();
    elements.uploadZone.classList.add('drag-over');
}

function handleDragLeave(e) {
    e.preventDefault();
    elements.uploadZone.classList.remove('drag-over');
}

function handleDrop(e) {
    e.preventDefault();
    elements.uploadZone.classList.remove('drag-over');
    
    const files = e.dataTransfer.files;
    processFiles(files);
}

function handleFileSelect(e) {
    const files = e.target.files;
    processFiles(files);
}

/**
 * Process uploaded files
 */
async function processFiles(fileList) {
    const validExtensions = ['.csv', '.xls', '.xlsx'];
    const filesToProcess = [];

    for (const file of fileList) {
        const ext = '.' + file.name.split('.').pop().toLowerCase();
        if (validExtensions.includes(ext)) {
            filesToProcess.push(file);
        }
    }

    if (filesToProcess.length === 0) {
        showStatus('No valid files selected. Please upload CSV or Excel files.', 'error');
        return;
    }

    showStatus(`Processing ${filesToProcess.length} file(s)...`, 'info');

    for (const file of filesToProcess) {
        try {
            const result = await FileHandlers.readFile(file);
            
            // Detect datetime columns
            const dateTimeCols = FileHandlers.detectDateTimeColumns(result.columns, result.data);
            const dateTimeCol = dateTimeCols[0] || null;
            
            // Check for duplicate timestamps
            const hasDuplicates = dateTimeCol ? 
                FileHandlers.hasDuplicateTimestamps(result.data, dateTimeCol) : false;
            
            // Get date range
            const dateRange = dateTimeCol ?
                FileHandlers.getDateRange(result.data, dateTimeCol) : { earliest: null, latest: null };

            // Store file data
            AppState.files[file.name] = {
                file: file,
                data: result.data,
                columns: result.columns,
                headerRow: result.headerRow,
                dateTimeCol: dateTimeCol,
                dateTimeCols: dateTimeCols,
                hasDuplicates: hasDuplicates,
                dateRange: dateRange,
                selectedCols: {},
                units: {},
                cleanup: {},
                dupeHandling: 'Average values'
            };

            if (result.headerRow > 0) {
                console.log(`Detected data starting on line ${result.headerRow + 1} in ${file.name}`);
            }

        } catch (error) {
            console.error(`Error processing ${file.name}:`, error);
            showStatus(`Error reading ${file.name}: ${error.message}`, 'error');
        }
    }

    // Update UI
    updateFileList();
    updateFileConfigs();
    updateSectionVisibility();
    updateAlignmentOptions();
    updateDefaultDatesFromData();

    showStatus(`✅ Uploaded ${Object.keys(AppState.files).length} file(s)!`, 'success');
}

/**
 * Update the file list display
 */
function updateFileList() {
    elements.fileList.innerHTML = '';

    for (const [fileName, fileInfo] of Object.entries(AppState.files)) {
        const fileItem = document.createElement('div');
        fileItem.className = 'file-item';
        fileItem.innerHTML = `
            <div>
                <span class="file-item-name">${fileName}</span>
                <span class="file-item-size">(${FileHandlers.formatFileSize(fileInfo.file.size)})</span>
            </div>
            <button class="file-item-remove" data-filename="${fileName}" title="Remove file">✕</button>
        `;
        elements.fileList.appendChild(fileItem);
    }

    // Add remove handlers
    elements.fileList.querySelectorAll('.file-item-remove').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const fileName = e.target.dataset.filename;
            delete AppState.files[fileName];
            updateFileList();
            updateFileConfigs();
            updateSectionVisibility();
            updateAlignmentOptions();
        });
    });
}

/**
 * Update file configuration panels
 */
function updateFileConfigs() {
    elements.fileConfigs.innerHTML = '';

    for (const [fileName, fileInfo] of Object.entries(AppState.files)) {
        const panel = createFileConfigPanel(fileName, fileInfo);
        elements.fileConfigs.appendChild(panel);
    }
}

/**
 * Create a configuration panel for a file
 */
function createFileConfigPanel(fileName, fileInfo) {
    const panel = document.createElement('div');
    panel.className = 'file-config';
    panel.id = `config-${sanitizeId(fileName)}`;

    // Header
    const header = document.createElement('div');
    header.className = 'file-config-header';
    header.innerHTML = `
        <span class="file-config-title">📈 Data available from: ${fileName}</span>
        <span class="file-config-toggle">▼</span>
    `;
    header.addEventListener('click', () => panel.classList.toggle('open'));

    // Content
    const content = document.createElement('div');
    content.className = 'file-config-content';

    // Data preview table
    const preview = FileHandlers.getPreview(fileInfo.data, 2);
    const previewHtml = createDataTable(fileInfo.columns, preview);

    // Duplicate warning
    let dupeWarningHtml = '';
    if (fileInfo.hasDuplicates) {
        dupeWarningHtml = `
            <div class="duplicate-warning">
                <div class="duplicate-warning-title">⚠️ Duplicate timestamps detected</div>
                <div class="form-group">
                    <label>How should duplicates be handled?</label>
                    <select class="select dupe-handling" data-filename="${fileName}">
                        <option value="Average values">Average values</option>
                        <option value="Maximum value">Maximum value</option>
                        <option value="Minimum value">Minimum value</option>
                    </select>
                </div>
            </div>
        `;
    }

    // Column selection
    const columnsHtml = createColumnSelector(fileName, fileInfo);

    content.innerHTML = `
        <div class="data-preview">${previewHtml}</div>
        ${dupeWarningHtml}
        <h4 style="color: var(--text-primary); margin-bottom: var(--spacing-md);">
            Select data columns to include in the combination
        </h4>
        ${columnsHtml}
        <div class="column-settings" id="column-settings-${sanitizeId(fileName)}"></div>
    `;

    panel.appendChild(header);
    panel.appendChild(content);

    // Set up event listeners after adding to DOM
    setTimeout(() => {
        setupFileConfigListeners(fileName, fileInfo);
    }, 0);

    return panel;
}

/**
 * Create HTML for data preview table
 */
function createDataTable(columns, rows) {
    let html = '<table class="data-table"><thead><tr>';
    for (const col of columns) {
        html += `<th>${escapeHtml(col)}</th>`;
    }
    html += '</tr></thead><tbody>';

    for (const row of rows) {
        html += '<tr>';
        for (const col of columns) {
            const value = row[col];
            html += `<td>${value != null ? escapeHtml(String(value)) : ''}</td>`;
        }
        html += '</tr>';
    }

    html += '</tbody></table>';
    return html;
}

/**
 * Create column selector HTML
 */
function createColumnSelector(fileName, fileInfo) {
    const nonDateTimeCols = fileInfo.columns.filter(c => !fileInfo.dateTimeCols.includes(c));
    
    let html = `<select multiple class="multi-select column-selector" data-filename="${fileName}" size="6">`;
    for (const col of nonDateTimeCols) {
        html += `<option value="${escapeHtml(col)}">${escapeHtml(col)}</option>`;
    }
    html += '</select>';
    
    return html;
}

/**
 * Set up event listeners for file config panel
 */
function setupFileConfigListeners(fileName, fileInfo) {
    const panel = document.getElementById(`config-${sanitizeId(fileName)}`);
    if (!panel) return;

    // Column selector
    const selector = panel.querySelector('.column-selector');
    if (selector) {
        selector.addEventListener('change', () => {
            updateColumnSettings(fileName, Array.from(selector.selectedOptions).map(o => o.value));
        });
    }

    // Duplicate handling
    const dupeSelect = panel.querySelector('.dupe-handling');
    if (dupeSelect) {
        dupeSelect.addEventListener('change', (e) => {
            AppState.files[fileName].dupeHandling = e.target.value;
        });
    }
}

/**
 * Update column settings panel when columns are selected
 */
function updateColumnSettings(fileName, selectedColumns) {
    const fileInfo = AppState.files[fileName];
    const settingsContainer = document.getElementById(`column-settings-${sanitizeId(fileName)}`);
    
    if (!settingsContainer) return;

    // Update selected columns in state
    const newSelectedCols = {};
    const newUnits = {};
    const newCleanup = {};

    for (const col of selectedColumns) {
        newSelectedCols[col] = fileInfo.selectedCols[col] || col;
        newUnits[col] = fileInfo.units[col] || '';
        newCleanup[col] = fileInfo.cleanup[col] || 'Fill with nearest available value';
    }

    fileInfo.selectedCols = newSelectedCols;
    fileInfo.units = newUnits;
    fileInfo.cleanup = newCleanup;

    // Build settings HTML
    let html = '';
    for (const col of selectedColumns) {
        html += `
            <div class="column-setting-item" id="col-setting-${sanitizeId(fileName)}-${sanitizeId(col)}">
                <div class="column-setting-header" onclick="this.parentElement.classList.toggle('open')">
                    <span class="column-setting-name">⚙️ Settings for ${escapeHtml(col)}</span>
                    <span>▼</span>
                </div>
                <div class="column-setting-content">
                    <div class="column-setting-grid">
                        <div class="form-group">
                            <label>Data Column Title</label>
                            <input type="text" class="input col-title" 
                                data-filename="${fileName}" 
                                data-column="${col}"
                                value="${escapeHtml(fileInfo.selectedCols[col] || col)}">
                        </div>
                        <div class="form-group">
                            <label>Units</label>
                            <input type="text" class="input col-units"
                                data-filename="${fileName}"
                                data-column="${col}"
                                value="${escapeHtml(fileInfo.units[col] || '')}">
                        </div>
                        <div class="form-group">
                            <label>Missing data handling</label>
                            <select class="select col-cleanup"
                                data-filename="${fileName}"
                                data-column="${col}">
                                <option value="Fill with nearest available value" 
                                    ${fileInfo.cleanup[col] === 'Fill with nearest available value' ? 'selected' : ''}>
                                    Fill with nearest available value
                                </option>
                                <option value="Fill with a linear interpolation between the nearest values"
                                    ${fileInfo.cleanup[col] === 'Fill with a linear interpolation between the nearest values' ? 'selected' : ''}>
                                    Fill with linear interpolation
                                </option>
                                <option value="Delete the entire row of data"
                                    ${fileInfo.cleanup[col] === 'Delete the entire row of data' ? 'selected' : ''}>
                                    Delete the entire row
                                </option>
                                <option value="Fill with zero"
                                    ${fileInfo.cleanup[col] === 'Fill with zero' ? 'selected' : ''}>
                                    Fill with zero
                                </option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    settingsContainer.innerHTML = html;

    // Add event listeners for settings inputs
    settingsContainer.querySelectorAll('.col-title').forEach(input => {
        input.addEventListener('change', (e) => {
            const fn = e.target.dataset.filename;
            const col = e.target.dataset.column;
            AppState.files[fn].selectedCols[col] = e.target.value;
            updateGraphColumnOptions();
        });
    });

    settingsContainer.querySelectorAll('.col-units').forEach(input => {
        input.addEventListener('change', (e) => {
            const fn = e.target.dataset.filename;
            const col = e.target.dataset.column;
            AppState.files[fn].units[col] = e.target.value;
        });
    });

    settingsContainer.querySelectorAll('.col-cleanup').forEach(select => {
        select.addEventListener('change', (e) => {
            const fn = e.target.dataset.filename;
            const col = e.target.dataset.column;
            AppState.files[fn].cleanup[col] = e.target.value;
        });
    });

    // Update graph column options
    updateGraphColumnOptions();
}

// ===== SECTION VISIBILITY =====

function updateSectionVisibility() {
    const hasFiles = Object.keys(AppState.files).length > 0;

    elements.columnsSection.classList.toggle('hidden', !hasFiles);
    elements.graphSection.classList.toggle('hidden', !hasFiles);
    elements.timeSection.classList.toggle('hidden', !hasFiles);
    elements.downloadSection.classList.toggle('hidden', !hasFiles);
}

// ===== ALIGNMENT OPTIONS =====

function updateAlignmentOptions() {
    elements.alignmentOptions.innerHTML = '';

    for (const fileName of Object.keys(AppState.files)) {
        const div = document.createElement('div');
        div.className = 'form-group';
        div.innerHTML = `
            <label>Data from '${escapeHtml(fileName)}':</label>
            <select class="select alignment-select" data-filename="${fileName}">
                <option value="Fill with the nearest value">Fill with the nearest value</option>
                <option value="Do a linear interpolation from the nearest values">Do a linear interpolation from the nearest values</option>
                <option value="Take an average of the available values within the interval">Take an average of the available values within the interval</option>
            </select>
        `;
        elements.alignmentOptions.appendChild(div);
    }
}

// ===== DATE DEFAULTS =====

function updateDefaultDatesFromData() {
    let latestStart = null;

    for (const fileInfo of Object.values(AppState.files)) {
        if (fileInfo.dateRange.earliest) {
            if (!latestStart || fileInfo.dateRange.earliest > latestStart) {
                latestStart = fileInfo.dateRange.earliest;
            }
        }
    }

    if (latestStart) {
        const startDate = new Date(latestStart);
        startDate.setDate(startDate.getDate() + 1);
        elements.startDate.value = formatDateForInput(startDate);

        const endDate = new Date(startDate);
        endDate.setDate(endDate.getDate() + 14);
        elements.endDate.value = formatDateForInput(endDate);
    }
}

// ===== RANGE MODE =====

function handleRangeModeChange(e) {
    const mode = e.target.value;
    document.getElementById('end-date-inputs').classList.toggle('hidden', mode === 'duration');
    document.getElementById('duration-input').classList.toggle('hidden', mode === 'end-date');
}

// ===== GRAPHING =====

function handleGraphingToggle() {
    const enabled = elements.enableGraphing.checked;
    elements.graphColumnSelect.classList.toggle('hidden', !enabled);
    
    if (enabled) {
        updateGraphColumnOptions();
    }
}

function updateGraphColumnOptions() {
    elements.graphColumns.innerHTML = '';

    for (const [fileName, fileInfo] of Object.entries(AppState.files)) {
        for (const [col, title] of Object.entries(fileInfo.selectedCols)) {
            const option = document.createElement('option');
            option.value = `${fileName}::${col}`;
            option.textContent = `${fileName} - ${title}`;
            elements.graphColumns.appendChild(option);
        }
    }
}

async function generateGraph() {
    const selectedOptions = Array.from(elements.graphColumns.selectedOptions);
    if (selectedOptions.length === 0) {
        showStatus('Please select at least one column to graph.', 'warning');
        return;
    }

    const traces = [];

    for (const option of selectedOptions) {
        const [fileName, col] = option.value.split('::');
        const fileInfo = AppState.files[fileName];
        
        if (!fileInfo) continue;

        const dateTimeCol = fileInfo.dateTimeCol;
        const data = fileInfo.data;

        // Sort by datetime
        const sorted = [...data].sort((a, b) => {
            return new Date(a[dateTimeCol]) - new Date(b[dateTimeCol]);
        });

        const x = sorted.map(row => new Date(row[dateTimeCol]));
        const y = sorted.map(row => parseFloat(row[col]));

        traces.push({
            x: x,
            y: y,
            mode: 'lines+markers',
            name: fileInfo.selectedCols[col] || col,
            type: 'scatter'
        });
    }

    const layout = {
        title: 'Combined Data Plot (All Files)',
        xaxis: { title: 'Date/Time' },
        yaxis: { title: 'Value' },
        hovermode: 'x unified',
        legend: { orientation: 'h', y: -0.2 },
        paper_bgcolor: '#12121a',
        plot_bgcolor: '#0a0a0f',
        font: { color: '#e0e0e0' },
        xaxis: {
            gridcolor: '#2a2a3a',
            title: 'Date/Time'
        },
        yaxis: {
            gridcolor: '#2a2a3a',
            title: 'Value'
        }
    };

    elements.graphContainer.classList.remove('hidden');
    Plotly.newPlot('plot', traces, layout, { responsive: true });
}

// ===== CREATE COMBINED FILE =====

async function createCombinedFile() {
    // Validate we have data
    let hasSelectedColumns = false;
    for (const fileInfo of Object.values(AppState.files)) {
        if (Object.keys(fileInfo.selectedCols).length > 0) {
            hasSelectedColumns = true;
            break;
        }
    }

    if (!hasSelectedColumns) {
        showStatus('Please select at least one column from at least one file.', 'error');
        return;
    }

    // Get time settings
    const startDate = new Date(elements.startDate.value + 'T' + elements.startTime.value);
    
    let endDate;
    const rangeMode = document.querySelector('input[name="range-mode"]:checked').value;
    if (rangeMode === 'end-date') {
        endDate = new Date(elements.endDate.value + 'T' + elements.endTime.value);
    } else {
        const days = parseInt(elements.durationDays.value) || 14;
        endDate = new Date(startDate);
        endDate.setDate(endDate.getDate() + days);
    }

    const interval = elements.interval.value;

    // Get alignment options
    const alignmentOptions = {};
    elements.alignmentOptions.querySelectorAll('.alignment-select').forEach(select => {
        alignmentOptions[select.dataset.filename] = select.value;
    });

    // Show progress
    elements.createFileBtn.disabled = true;
    elements.progressContainer.classList.remove('hidden');
    updateProgress(0, 'Starting file processing...');

    try {
        // Generate timestamps
        const timestamps = DataProcessing.generateTimeIndex(startDate, endDate, interval);
        updateProgress(10, `Generated ${timestamps.length} timestamps...`);

        // Create combined dataset
        const combined = DataProcessing.createCombinedDataset(
            AppState.files, 
            timestamps, 
            alignmentOptions
        );
        updateProgress(50, 'Data combined, preparing Excel file...');

        // Fetch template
        let workbook;
        try {
            const response = await fetch(AppState.templateUrl);
            if (response.ok) {
                const templateBuffer = await response.arrayBuffer();
                workbook = XLSX.read(templateBuffer, { type: 'array' });
            } else {
                // Create new workbook if template not found
                console.log('Template not found, creating new workbook');
                workbook = XLSX.utils.book_new();
                const ws = XLSX.utils.aoa_to_sheet([[]]);
                XLSX.utils.book_append_sheet(workbook, ws, 'Analysis');
            }
        } catch (e) {
            console.log('Could not load template, creating new workbook:', e);
            workbook = XLSX.utils.book_new();
            const ws = XLSX.utils.aoa_to_sheet([[]]);
            XLSX.utils.book_append_sheet(workbook, ws, 'Analysis');
        }

        updateProgress(70, 'Writing data to Excel...');

        // Get or create Analysis sheet
        let ws = workbook.Sheets['Analysis'];
        if (!ws) {
            ws = XLSX.utils.aoa_to_sheet([[]]);
            XLSX.utils.book_append_sheet(workbook, ws, 'Analysis');
        }

        // Write headers (Row 10 in Excel = index 9)
        const headers = ['Date', ...combined.columns];
        const units = ['', ...combined.units];

        // Row 10 - Headers
        for (let c = 0; c < headers.length; c++) {
            const cellRef = XLSX.utils.encode_cell({ r: 9, c: c + 1 }); // B10, C10, etc.
            ws[cellRef] = { t: 's', v: headers[c] };
        }

        // Row 11 - Units
        for (let c = 0; c < units.length; c++) {
            const cellRef = XLSX.utils.encode_cell({ r: 10, c: c + 1 });
            ws[cellRef] = { t: 's', v: units[c] };
        }

        // Row 12 onward - Data
        for (let r = 0; r < combined.data.length; r++) {
            const row = combined.data[r];
            
            // Date column (B)
            const dateCell = XLSX.utils.encode_cell({ r: 11 + r, c: 1 });
            ws[dateCell] = { t: 'd', v: row.DateTime };

            // Data columns (C onward)
            for (let c = 0; c < combined.columns.length; c++) {
                const cellRef = XLSX.utils.encode_cell({ r: 11 + r, c: c + 2 });
                const value = row[combined.columns[c]];
                
                if (value !== null && value !== undefined) {
                    ws[cellRef] = { t: 'n', v: value };
                }
            }

            // Update progress periodically
            if (r % 100 === 0) {
                updateProgress(70 + (r / combined.data.length) * 25, 
                    `Writing row ${r + 1} of ${combined.data.length}...`);
            }
        }

        // Update sheet range
        const lastRow = 11 + combined.data.length;
        const lastCol = 1 + combined.columns.length;
        ws['!ref'] = XLSX.utils.encode_range({
            s: { r: 0, c: 0 },
            e: { r: lastRow, c: lastCol }
        });

        updateProgress(95, 'Generating download...');

        // Generate file
        const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
        const blob = new Blob([wbout], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        
        // Create download link
        const url = URL.createObjectURL(blob);
        
        elements.downloadBtn.onclick = () => {
            const a = document.createElement('a');
            a.href = url;
            a.download = 'Analysis.xlsx';
            a.click();
        };

        elements.downloadContainer.classList.remove('hidden');
        updateProgress(100, '✅ Combined file created!');

        showStatus('✅ Combined file created! Click the download button to save.', 'success');

    } catch (error) {
        console.error('Error creating combined file:', error);
        showStatus(`Error creating file: ${error.message}`, 'error');
    } finally {
        elements.createFileBtn.disabled = false;
    }
}

// ===== UTILITY FUNCTIONS =====

function showStatus(message, type = 'info') {
    elements.uploadStatus.textContent = message;
    elements.uploadStatus.className = `status-message status-${type}`;
    elements.uploadStatus.classList.remove('hidden');
    
    // Auto-hide after 5 seconds for non-errors
    if (type !== 'error') {
        setTimeout(() => {
            elements.uploadStatus.classList.add('hidden');
        }, 5000);
    }
}

function updateProgress(percent, text) {
    elements.progressFill.style.width = `${percent}%`;
    elements.progressText.textContent = text;
}

function sanitizeId(str) {
    return str.replace(/[^a-zA-Z0-9]/g, '_');
}

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', init);
